# Validation summary

This pack corresponds to the ACE K2 source-fix validation published at:

https://doi.org/10.5281/zenodo.23267518

## Causal A/B

The test held the source revision, build toolchain, target (`gfx1151`), reproducer and runtime support set constant while changing only the source patch under test.

### Forced-pristine arm

`PAL_DISABLE_SDMA` was not set. SDMA remained enabled.

| Cell | Result |
|---|---|
| upload | clean 50/50 |
| upload-ptr | clean 50/50 |
| upload-norec | clean 50/50 |
| read | **STALE 50/50** |
| read-ptr | clean 50/50 |
| read-norec | clean 50/50 |

Pristine runtime SHA-256:

`D7FFE506C474FDB5ABE75AD3189B4607C59E13A4A2AB929631E5E01CE48D3124`

### Forced-patched arm

`PAL_DISABLE_SDMA` was also not set. The PAL source file was forcibly recompiled before relinking the runtime.

| Cell | Result |
|---|---|
| upload | clean 50/50 |
| upload-ptr | clean 50/50 |
| upload-norec | clean 50/50 |
| read | clean 50/50 |
| read-ptr | clean 50/50 |
| read-norec | clean 50/50 |

Patched runtime SHA-256:

`5398EC065D66ACA548F24F3F0D6F95C4633B69925287DFA080F8893307B89785`

## Evaluator conclusion

Independent ACE evaluator:

- Decision: `ACCEPT`
- Classification: `PATCH_VALIDATED_SDMA_ENABLED`
- Causal conclusion: `PATCH_CAUSALLY_CLEARS_FORCED_PRISTINE_REPRO`

## What this establishes

For the bounded Windows Radeon 8060S / gfx1151 test, preserving the durable compute event in the included patch changes the same physical reproducer from deterministic stale reads to clean results while SDMA remains enabled.

## What this does not establish

It does not establish universal correctness or performance across all Windows ROCm GPUs, drivers or workloads. Independent builds on other Windows targets are specifically encouraged.

The ACE patch is also not source-identical to AMD PR #12952. The published report discusses the relationship between the two implementations.
