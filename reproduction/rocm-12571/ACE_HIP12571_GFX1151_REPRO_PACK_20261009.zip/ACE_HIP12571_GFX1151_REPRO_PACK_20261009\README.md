# ACE validation pack for ROCm/rocm-systems #12571

This source-only pack contains the material needed to independently reproduce the ACE K2 validation of the Windows PAL/SDMA ordering fix for ROCm/rocm-systems issue #12571.

It deliberately does **not** contain `amdhip64_7.dll` or any other executable DLL. The preferred reproduction path is to build the runtime independently from the pinned source and apply the included minimal patch.

## What ACE validated

Platform used for the published validation:

- Windows 11
- AMD Ryzen AI MAX+ 395 / Radeon 8060S (`gfx1151`)
- TheRock revision: `6d2136cd12be28c6251eb38c700e980c8c2f8cf6`
- rocm-systems revision: `79e85e1468f96a867108043c953e9547c13b4c5e`
- Patch name used by ACE: `lastComputeEvent_v1`
- SDMA enabled in both pristine and patched A/B arms

Forced-pristine result:

- `read`: `STALE 50/50`
- other five cells: clean `50/50`

Forced-patched result:

- all six cells: clean `50/50`

Independent ACE evaluator result: `ACCEPT / PATCH_VALIDATED_SDMA_ENABLED`.

## Pack contents

- `patches/ace_lastComputeEvent_v1.patch` — the exact minimal source diff tested by ACE.
- `reproducer/repro_hip.py` — the exact HIP-runtime reproducer used in the validated A/B run.
- `BUILD_WINDOWS.md` — Windows build and reproduction procedure derived from the validated build.
- `PROVENANCE.json` — pinned revisions and published validation hashes.
- `VALIDATION.md` — expected A/B outcomes and scope limits.
- `SHA256SUMS.txt` — hashes of the files in this pack.

## Quick path

1. Obtain the exact rocm-systems source revision above.
2. Apply `patches/ace_lastComputeEvent_v1.patch` with `git apply`.
3. Build `amdhip64_7.dll` against a matching TheRock/ROCm 7.13.0 Windows stack as described in `BUILD_WINDOWS.md`.
4. Assemble a test directory containing the newly built `amdhip64_7.dll` plus the matching support DLLs from the same stack.
5. Run `reproducer/repro_hip.py` first with the pristine runtime and then with the patched runtime, keeping SDMA enabled in both cases.

For a different Windows ROCm target, use the target's correct `--arch` value and a matched runtime/support-DLL stack. Do not expect the exact failure frequency to be identical on every GPU; the key comparison is pristine versus patched under otherwise identical conditions.

## Important scope note

This pack demonstrates a bounded causal A/B on the tested Windows `gfx1151` configuration. It is not a claim that every ROCm platform, driver, or workload has been validated.

The ACE patch is not source-identical to AMD PR #12952, although both preserve compute-event state across the relevant flush path.

## References

- Upstream issue: https://github.com/ROCm/rocm-systems/issues/12571
- AMD PR: https://github.com/ROCm/rocm-systems/pull/12952
- Published ACE report: https://doi.org/10.5281/zenodo.23267518
