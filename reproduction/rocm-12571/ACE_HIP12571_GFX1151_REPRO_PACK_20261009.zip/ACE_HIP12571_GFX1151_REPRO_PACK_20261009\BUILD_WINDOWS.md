# Windows build and reproduction notes

These commands are generalized from the exact ACE build that produced the validated `gfx1151` result. Paths are placeholders; keep the source revision and runtime/support-DLL stack matched.

## Validated toolchain context

ACE's successful build used:

- Visual Studio Build Tools v18 developer environment (`vcvars64.bat`)
- Windows SDK `10.0.26100.0`
- CMake + Ninja
- a matched TheRock/ROCm `gfx1151-7.13.0` installation for headers, libraries, LLVM tools and support DLLs
- rocm-systems commit `79e85e1468f96a867108043c953e9547c13b4c5e`

The TheRock checkout associated with the installed stack was `6d2136cd12be28c6251eb38c700e980c8c2f8cf6`.

## 1. Prepare source

Clone rocm-systems and checkout the exact tested revision:

```bat
git clone https://github.com/ROCm/rocm-systems.git
git -C rocm-systems checkout 79e85e1468f96a867108043c953e9547c13b4c5e
```

Apply the ACE patch from the root of the checkout:

```bat
git apply path\to\ace_lastComputeEvent_v1.patch
```

For auditability, the expected source hashes after applying the patch are recorded in `PROVENANCE.json`.

## 2. Configure CLR/HIP runtime

Set these placeholders to your local paths:

```bat
set SRC=C:\src\rocm-systems
set BLD=C:\build\rocm-clr-12571
set DST=C:\build\rocm-clr-12571-install
set ROCM=C:\path\to\matched\gfx1151-7.13.0
set SDK=C:\Program Files (x86)\Windows Kits\10
set SDKVER=10.0.26100.0
```

Enter the x64 Visual Studio developer environment, then ensure the Windows SDK tools, matching ROCm `bin`, ROCm LLVM tools and Ninja are on `PATH`.

The validated CMake configuration was equivalent to:

```bat
cmake -S "%SRC%\projects\clr" -B "%BLD%" -G Ninja ^
  -DCMAKE_BUILD_TYPE=Release ^
  -DCMAKE_C_COMPILER=cl.exe ^
  -DCMAKE_CXX_COMPILER=cl.exe ^
  -DCMAKE_RC_COMPILER="%SDK%\bin\%SDKVER%\x64\rc.exe" ^
  -DCMAKE_MT="%SDK%\bin\%SDKVER%\x64\mt.exe" ^
  -DCMAKE_INSTALL_PREFIX="%DST%" ^
  -DCMAKE_PREFIX_PATH="%ROCM%" ^
  -DROCM_PATH="%ROCM%" ^
  -DHIP_PLATFORM=amd ^
  -DHIP_COMMON_DIR="%SRC%\projects\hip" ^
  -DCLR_BUILD_HIP=ON ^
  -DROCM_KPACK_ENABLED=ON ^
  -DHIPCC_BIN_DIR= ^
  -DUSE_PROF_API=OFF ^
  -D__HIP_ENABLE_PCH=OFF ^
  -DROCCLR_ENABLE_PAL=ON ^
  -DROCCLR_ENABLE_HSA=ON ^
  -D__HIP_ENABLE_RTC=ON ^
  -DROCR_DLL_LOAD=OFF ^
  -DAMD_COMPUTE_WIN="%SRC%\shared\amdgpu-windows-interop" ^
  -DCOMGR_DLL_NAME=amd_comgr0713.dll
```

## 3. Build amdhip64

```bat
ninja -C "%BLD%" amdhip64
```

The resulting runtime is expected under:

```text
%BLD%\hipamd\src\amdhip64_7.dll
```

## 4. Assemble a matched test runtime directory

Place the built `amdhip64_7.dll` beside the support DLLs from the **same matched ROCm/TheRock stack**. ACE's validated runtime directory contained:

```text
amdhip64_7.dll
amd_comgr0713.dll
amdocl64.dll
cltrace.dll
hiprtc07013.dll
hiprtc-builtins07013.dll
rocm_kpack.dll
```

Do not mix an independently built `amdhip64_7.dll` with unrelated COMGR/HIPRTC/device-library versions; ABI/runtime skew can invalidate the test.

## 5. Run the exact gfx1151 test matrix

With SDMA enabled, remove/leave unset these variables before running:

```text
PAL_DISABLE_SDMA
AMD_SERIALIZE_COPY
AMD_SERIALIZE_KERNEL
AMD_LOG_LEVEL
AMD_DIRECT_DISPATCH
HIP_LAUNCH_BLOCKING
```

ACE invoked the reproducer with the following parameters:

```bat
python repro_hip.py ^
  --dll C:\path\to\runtime\amdhip64_7.dll ^
  --hiprtc hiprtc07013.dll ^
  --arch gfx1151 ^
  --iters-per-cell 50 ^
  --cells upload,upload-ptr,upload-norec,read,read-ptr,read-norec ^
  --launch fatbin ^
  --kernel-ms 10 ^
  --behind-ms 20 ^
  --ceiling 45 ^
  --out C:\path\to\results ^
  --seed 0
```

For strict identity checking, also pass:

```text
--dll-sha256 <sha256-of-the-runtime-being-tested>
```

Run once using a pristine build from the pinned commit and once using a patched build from the same source/toolchain/runtime support set.

## 6. Expected validated result on gfx1151

Pristine:

```text
upload         clean 50/50
upload-ptr     clean 50/50
upload-norec   clean 50/50
read           STALE 50/50
read-ptr       clean 50/50
read-norec     clean 50/50
```

Patched:

```text
all six cells  clean 50/50
```

The comparison is the important result. A different Windows GPU may exhibit a different failure rate or timing window.
