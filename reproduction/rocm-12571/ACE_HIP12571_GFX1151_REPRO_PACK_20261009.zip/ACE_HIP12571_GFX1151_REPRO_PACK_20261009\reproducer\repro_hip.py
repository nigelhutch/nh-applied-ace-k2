"""Minimal HIP reproducer, no PyTorch: after hipEventRecord, a copy on the same
stream is not ordered behind a still-running kernel whose buffer reaches it only
inside a by-value struct argument (HIP on Windows).

    python repro_hip.py [--dll PATH\\amdhip64_7.dll] [--arch gfx1201] [--iters-per-cell 150]
                        [--cells upload,upload-ptr,upload-norec,read,read-ptr,read-norec]
                        [--launch fatbin|module] [--kernel-ms 10] [--behind-ms 20]
                        [--out DIR] [--ceiling SECONDS]

Needs only the HIP runtime and hiprtc DLLs, for example from the ROCm Python wheel
(`_rocm_sdk_core\\bin`, found automatically when that package is installed) or
from a HIP SDK (pass --dll). Python 3.9+, the standard library only.

One host thread, the null stream. Each iteration:
  1. X (80 KiB) is filled with OLD, then the device is synchronized.
  2. About --behind-ms of short spin kernels are queued on a scratch buffer, so the
     device lags the host.
  3. WRITER: one block of 256 threads spins about --kernel-ms (wall_clock64), then
     writes W over X's FIRST half.
       struct cells: X's pointer is a field of the kernel's one by-value struct
                     argument (this is how PyTorch's kernels receive their pointers);
       *-ptr cells:  the same kernel, with X ALSO passed as an unused pointer argument.
  4. READER: y = x + 1 over all of X (pointers in a by-value struct).
  5. hipEventRecord(ev, 0)                                   (not in the *-norec cells)
  6. upload cells: hipMemcpyAsync(X, pinned host C, 80 KiB, H2D, 0)
     read cells:   hipMemcpyWithStream(pageable host H, X, 80 KiB, D2H, 0)
                   (the call PyTorch makes for a blocking tensor.cpu())
  7. hipDeviceSynchronize, then check.

Stream order says step 6 runs after step 3 has finished. So:
  upload: X must equal C. OVERWRITTEN = X's first half holds W: the writer, queued
          BEFORE the copy, wrote after it.
  read:   H must hold W in the first half and OLD in the second.
          STALE = H holds OLD everywhere: the read ran before the writer's store.
          MIXED = part of the store is missing.

--launch fatbin (default) registers the code object as a fat binary
(__hipRegisterFatBinary + __hipRegisterFunction) and launches with hipLaunchKernel,
as a hipcc-compiled program does. --launch module uses hipModuleLoadData +
hipModuleLaunchKernel.

Nothing printed contains a file path; --out DIR/repro_hip.json is the only file
written.
"""
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
import random
import struct
import sys
import time

ap = argparse.ArgumentParser()
ap.add_argument("--dll", default=None, help="path to amdhip64_7.dll (hiprtc next to it)")
ap.add_argument("--dll-sha256", default=None, help="refuse a DLL with another sha256")
ap.add_argument("--hiprtc", default="hiprtc0702.dll")
ap.add_argument("--arch", default="gfx1201")
ap.add_argument("--iters-per-cell", type=int, default=150)
ap.add_argument("--cells", default="upload,upload-ptr,upload-norec,read,read-ptr,read-norec")
ap.add_argument("--launch", choices=("fatbin", "module"), default="fatbin")
ap.add_argument("--kernel-ms", type=float, default=10.0)
ap.add_argument("--behind-ms", type=float, default=20.0)
ap.add_argument("--ceiling", type=float, default=0.0,
                help="stop starting iterations after this many seconds (0: no limit)")
ap.add_argument("--out", default=None, help="write repro_hip.json into this directory")
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--compile-only", action="store_true",
                help="compile the kernels with hiprtc and exit (never loads the runtime)")
a = ap.parse_args()

CELLS = ("upload", "upload-ptr", "upload-norec", "read", "read-ptr", "read-norec")
cells = [c for c in a.cells.split(",") if c]
for c in cells:
    if c not in CELLS:
        raise SystemExit(f"repro_hip: unknown cell {c!r}; known: {', '.join(CELLS)}")

NW = 10240                         # X: int64 words (80 KiB)
HALF = NW // 2                     # the writer writes X[:HALF]
NB = NW * 8
OLD = 0x5EED5EED5EED5EED
W = 0x0777077707770777
SENT = 0x0BADF00D0BADF00D          # the read cells' host pre-fill
SCRATCH_WORDS = 256
MAX_KERNEL_MS = 500.0              # refuse a longer kernel (far below the 2-s TDR)
H2D, D2H = 1, 2
EVENT_DISABLE_TIMING = 0x2

SRC = r'''
struct WArgs { long long* x; unsigned int n; long long w; long long cycles; };
struct RArgs { const long long* x; long long* y; unsigned int n; };

extern "C" __global__ void write_struct(WArgs a) {
    long long t0 = wall_clock64();
    while (wall_clock64() - t0 < a.cycles) { }
    for (unsigned int i = threadIdx.x; i < a.n; i += blockDim.x) a.x[i] = a.w;
}

// the same body; `alias` is never read (the launcher passes alias = a.x)
extern "C" __global__ void write_ptr(WArgs a, long long* alias) {
    long long t0 = wall_clock64();
    while (wall_clock64() - t0 < a.cycles) { }
    for (unsigned int i = threadIdx.x; i < a.n; i += blockDim.x) a.x[i] = a.w;
}

extern "C" __global__ void read_struct(RArgs a) {
    for (unsigned int i = blockIdx.x * blockDim.x + threadIdx.x; i < a.n;
         i += blockDim.x * gridDim.x) a.y[i] = a.x[i] + 1;
}
'''
KERNELS = ("write_struct", "write_ptr", "read_struct")


class WArgs(ctypes.Structure):
    _fields_ = [("x", ctypes.c_void_p), ("n", ctypes.c_uint), ("w", ctypes.c_longlong),
                ("cycles", ctypes.c_longlong)]


class RArgs(ctypes.Structure):
    _fields_ = [("x", ctypes.c_void_p), ("y", ctypes.c_void_p), ("n", ctypes.c_uint)]


class Dim3(ctypes.Structure):
    _fields_ = [("x", ctypes.c_uint32), ("y", ctypes.c_uint32), ("z", ctypes.c_uint32)]


class FatWrapper(ctypes.Structure):
    _fields_ = [("magic", ctypes.c_uint32), ("version", ctypes.c_uint32),
                ("binary", ctypes.c_void_p), ("dummy", ctypes.c_void_p)]


vp, sz = ctypes.c_void_p, ctypes.c_size_t


def find_dll():
    if a.dll:
        return a.dll
    spec = importlib.util.find_spec("_rocm_sdk_core")   # finds, does not import
    if spec and spec.submodule_search_locations:
        p = os.path.join(list(spec.submodule_search_locations)[0], "bin", "amdhip64_7.dll")
        if os.path.exists(p):
            return p
    raise SystemExit("repro_hip: amdhip64_7.dll not found; pass --dll PATH")


def compile_code(bindir):
    """hiprtc -> one code object with the three kernels. hiprtc alone does not
    load the HIP runtime."""
    rtc = ctypes.CDLL(os.path.join(bindir, a.hiprtc))
    rtc.hiprtcCreateProgram.argtypes = [ctypes.POINTER(vp), ctypes.c_char_p,
                                        ctypes.c_char_p, ctypes.c_int, vp, vp]
    rtc.hiprtcCompileProgram.argtypes = [vp, ctypes.c_int, ctypes.POINTER(ctypes.c_char_p)]
    rtc.hiprtcGetProgramLogSize.argtypes = [vp, ctypes.POINTER(sz)]
    rtc.hiprtcGetProgramLog.argtypes = [vp, ctypes.c_char_p]
    rtc.hiprtcGetCodeSize.argtypes = [vp, ctypes.POINTER(sz)]
    rtc.hiprtcGetCode.argtypes = [vp, ctypes.c_char_p]
    rtc.hiprtcDestroyProgram.argtypes = [ctypes.POINTER(vp)]
    prog = vp()
    if rtc.hiprtcCreateProgram(ctypes.byref(prog), SRC.encode(), b"repro.hip", 0,
                               None, None):
        raise SystemExit("repro_hip: hiprtcCreateProgram failed")
    opts = (ctypes.c_char_p * 1)(f"--offload-arch={a.arch}".encode())
    rc = rtc.hiprtcCompileProgram(prog, 1, opts)
    n = sz(0)
    rtc.hiprtcGetProgramLogSize(prog, ctypes.byref(n))
    log = ctypes.create_string_buffer(max(n.value, 1))
    rtc.hiprtcGetProgramLog(prog, log)
    if rc:
        raise SystemExit(f"repro_hip: hiprtcCompileProgram {rc}: "
                         f"{log.value.decode(errors='replace')[:800]}")
    rtc.hiprtcGetCodeSize(prog, ctypes.byref(n))
    code = ctypes.create_string_buffer(n.value)
    rtc.hiprtcGetCode(prog, code)
    rtc.hiprtcDestroyProgram(ctypes.byref(prog))
    return code.raw


def bundle(code):
    """A clang offload bundle with an empty host entry and one device entry, as
    hipcc embeds it: [magic][u64 n], per entry [u64 off][u64 size][u64 len][triple],
    then the device code 4096-aligned."""
    magic = b"__CLANG_OFFLOAD_BUNDLE__"
    entries = [("host-x86_64-pc-windows-msvc", b""),
               (f"hipv4-amdgcn-amd-amdhsa--{a.arch}", code)]
    off = len(magic) + 8 + sum(24 + len(t) for t, _ in entries)
    offs = []
    for _, b in entries:
        if b:
            off = (off + 4095) // 4096 * 4096
        offs.append(off)
        off += len(b)
    out = bytearray(magic + struct.pack("<Q", len(entries)))
    for (t, b), o in zip(entries, offs):
        out += struct.pack("<QQQ", o, len(b), len(t)) + t.encode()
    for (_, b), o in zip(entries, offs):
        if b:
            out += b"\0" * (o - len(out)) + b
    return bytes(out)


class Runtime:
    def __init__(self, dll, code):
        os.add_dll_directory(os.path.dirname(os.path.abspath(dll)))
        self.hip = hip = ctypes.CDLL(dll)
        sig = {"hipSetDevice": [ctypes.c_int],
               "hipDeviceGetName": [ctypes.c_char_p, ctypes.c_int, ctypes.c_int],
               "hipRuntimeGetVersion": [ctypes.POINTER(ctypes.c_int)],
               "hipDriverGetVersion": [ctypes.POINTER(ctypes.c_int)],
               "hipMalloc": [ctypes.POINTER(vp), sz], "hipFree": [vp],
               "hipHostMalloc": [ctypes.POINTER(vp), sz, ctypes.c_uint],
               "hipHostFree": [vp],
               "hipMemcpy": [vp, vp, sz, ctypes.c_int],
               "hipMemcpyAsync": [vp, vp, sz, ctypes.c_int, vp],
               "hipMemcpyWithStream": [vp, vp, sz, ctypes.c_int, vp],
               "hipEventCreateWithFlags": [ctypes.POINTER(vp), ctypes.c_uint],
               "hipEventCreate": [ctypes.POINTER(vp)],
               "hipEventRecord": [vp, vp], "hipEventDestroy": [vp],
               "hipEventSynchronize": [vp],
               "hipEventElapsedTime": [ctypes.POINTER(ctypes.c_float), vp, vp],
               "hipDeviceSynchronize": [],
               "hipModuleLoadData": [ctypes.POINTER(vp), vp],
               "hipModuleGetFunction": [ctypes.POINTER(vp), vp, ctypes.c_char_p],
               "hipModuleLaunchKernel": [vp, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                                         ctypes.c_uint, ctypes.c_uint, ctypes.c_uint,
                                         ctypes.c_uint, vp, ctypes.POINTER(vp),
                                         ctypes.POINTER(vp)],
               "hipLaunchKernel": [vp, Dim3, Dim3, ctypes.POINTER(vp), sz, vp]}
        for name, args in sig.items():
            f = getattr(hip, name)
            f.argtypes, f.restype = args, ctypes.c_int
        hip.hipGetErrorString.argtypes = [ctypes.c_int]
        hip.hipGetErrorString.restype = ctypes.c_char_p
        self.ck(hip.hipSetDevice(0), "hipSetDevice")
        self.keep = []
        if a.launch == "module":
            self.code = ctypes.create_string_buffer(code, len(code))
            mod = vp()
            self.ck(hip.hipModuleLoadData(ctypes.byref(mod), ctypes.cast(self.code, vp)),
                    "hipModuleLoadData")
            self.fn = {}
            for k in KERNELS:
                f = vp()
                self.ck(hip.hipModuleGetFunction(ctypes.byref(f), mod, k.encode()),
                        "hipModuleGetFunction")
                self.fn[k] = f
        else:
            reg_fat = getattr(hip, "__hipRegisterFatBinary")
            reg_fn = getattr(hip, "__hipRegisterFunction")
            reg_fat.restype, reg_fat.argtypes = ctypes.POINTER(vp), [vp]
            reg_fn.restype = None
            reg_fn.argtypes = [ctypes.POINTER(vp), vp, ctypes.c_char_p, ctypes.c_char_p,
                               ctypes.c_int, vp, vp, vp, vp, vp]
            b = bundle(code)
            blob = ctypes.create_string_buffer(b, len(b))
            wrapper = FatWrapper(0x48495046, 1, ctypes.cast(blob, vp), None)   # "HIPF"
            handle = reg_fat(ctypes.addressof(wrapper))
            if not handle:
                raise SystemExit("repro_hip: __hipRegisterFatBinary returned NULL")
            self.fn = {}
            for k in KERNELS:
                stub = ctypes.create_string_buffer(16)          # the host-side handle
                name = ctypes.create_string_buffer(k.encode())
                reg_fn(handle, ctypes.addressof(stub), name, name, -1,
                       None, None, None, None, None)
                self.fn[k] = stub
                self.keep += [stub, name]
            # the runtime holds pointers into these for the life of the process
            self.keep += [blob, wrapper]
            for o in self.keep:
                ctypes.pythonapi.Py_IncRef(ctypes.py_object(o))

    def ck(self, rc, what):
        if rc != 0:
            raise SystemExit(f"repro_hip: {what}: {rc} "
                             f"{self.hip.hipGetErrorString(rc).decode()}")

    def launch(self, kernel, grid, args):
        """args: the kernel's argument objects in order (ctypes values)."""
        params = (vp * len(args))(*[ctypes.cast(ctypes.byref(v), vp) for v in args])
        if a.launch == "module":
            rc = self.hip.hipModuleLaunchKernel(self.fn[kernel], grid, 1, 1, 256, 1, 1,
                                                0, None, params, None)
        else:
            rc = self.hip.hipLaunchKernel(ctypes.addressof(self.fn[kernel]),
                                          Dim3(grid, 1, 1), Dim3(256, 1, 1), params,
                                          0, None)
        self.ck(rc, f"launch {kernel}")

    def sync(self):
        self.ck(self.hip.hipDeviceSynchronize(), "hipDeviceSynchronize")


def classify_upload(x, c):
    """x, c: lists of NW int64. clean, OVERWRITTEN (first half W, second C), or other."""
    if x == c:
        return "clean"
    if all(v == W for v in x[:HALF]) and x[HALF:] == c[HALF:]:
        return "OVERWRITTEN"
    return "other"


def classify_read(h):
    """h: list of NW int64, the host copy of X. clean, STALE, MIXED, or other."""
    if any(v != OLD for v in h[HALF:]):
        return "other"
    n_w = sum(1 for v in h[:HALF] if v == W)
    n_old = sum(1 for v in h[:HALF] if v == OLD)
    if n_w == HALF:
        return "clean"
    if n_old == HALF:
        return "STALE"
    if n_w + n_old == HALF:
        return "MIXED"
    return "other"


def self_test():
    c = [i + 12345 for i in range(NW)]
    ok = classify_upload(list(c), c) == "clean"
    ok &= classify_upload([W] * HALF + c[HALF:], c) == "OVERWRITTEN"
    ok &= classify_upload([W] * HALF + [OLD] * HALF, c) == "other"
    ok &= classify_read([OLD] * NW) == "STALE"
    ok &= classify_read([W] * HALF + [OLD] * HALF) == "clean"
    ok &= classify_read([OLD] * 10 + [W] * (HALF - 10) + [OLD] * HALF) == "MIXED"
    ok &= classify_read([SENT] * NW) == "other"
    return bool(ok)


def s64(v):
    return v - (1 << 64) if v >= 1 << 63 else v


def main():
    if not self_test():
        raise SystemExit("repro_hip: classifier self-test FAILED")
    dll = find_dll()
    bindir = os.path.dirname(os.path.abspath(dll))
    os.add_dll_directory(bindir)
    code = compile_code(bindir)
    head = {"dll": os.path.basename(dll),
            "dll_sha256": hashlib.sha256(open(dll, "rb").read()).hexdigest(),
            "arch": a.arch, "launch": a.launch, "code_bytes": len(code),
            "code_sha256": hashlib.sha256(code).hexdigest(),
            "source_sha256": hashlib.sha256(SRC.encode()).hexdigest(),
            "env": {k: os.environ.get(k) for k in (
                "PAL_DISABLE_SDMA", "AMD_SERIALIZE_COPY", "AMD_SERIALIZE_KERNEL",
                "AMD_LOG_LEVEL", "AMD_DIRECT_DISPATCH", "HIP_LAUNCH_BLOCKING")}}
    if a.dll_sha256 and head["dll_sha256"] != a.dll_sha256:
        raise SystemExit("repro_hip: the DLL's sha256 differs from --dll-sha256")
    if a.compile_only:
        print("repro_hip:", json.dumps(head), flush=True)
        return
    rt = Runtime(dll, code)
    hip = rt.hip
    v = ctypes.c_int(0)
    rt.ck(hip.hipRuntimeGetVersion(ctypes.byref(v)), "hipRuntimeGetVersion")
    head["hipRuntimeGetVersion"] = v.value
    rt.ck(hip.hipDriverGetVersion(ctypes.byref(v)), "hipDriverGetVersion")
    head["hipDriverGetVersion"] = v.value
    name = ctypes.create_string_buffer(256)
    rt.ck(hip.hipDeviceGetName(name, 256, 0), "hipDeviceGetName")
    head["device"] = name.value.decode(errors="replace")
    print("repro_hip:", json.dumps(head), flush=True)

    X, Y, SCR, HC = vp(), vp(), vp(), vp()
    rt.ck(hip.hipMalloc(ctypes.byref(X), NB), "hipMalloc X")
    rt.ck(hip.hipMalloc(ctypes.byref(Y), NB), "hipMalloc Y")
    rt.ck(hip.hipMalloc(ctypes.byref(SCR), SCRATCH_WORDS * 8), "hipMalloc scratch")
    rt.ck(hip.hipHostMalloc(ctypes.byref(HC), NB, 0), "hipHostMalloc")   # pinned C
    host_c = (ctypes.c_longlong * NW).from_address(HC.value)
    host_h = (ctypes.c_longlong * NW)()                                   # pageable
    old = (ctypes.c_longlong * NW)(*([s64(OLD)] * NW))
    sent = (ctypes.c_longlong * NW)(*([s64(SENT)] * NW))
    check = (ctypes.c_longlong * NW)()

    def writer(kind, x, n, cycles):
        wa = WArgs(x.value, n, s64(W), int(cycles))
        if kind == "ptr":
            rt.launch("write_ptr", 1, [wa, vp(x.value)])
        else:
            rt.launch("write_struct", 1, [wa])

    def reader():
        rt.launch("read_struct", 10, [RArgs(X.value, Y.value, NW)])

    def dev_ms(fn):
        """Device time of fn() between two timing events (calibration only)."""
        e0, e1, ms = vp(), vp(), ctypes.c_float(0.0)
        rt.ck(hip.hipEventCreate(ctypes.byref(e0)), "hipEventCreate")
        rt.ck(hip.hipEventCreate(ctypes.byref(e1)), "hipEventCreate")
        rt.sync()
        rt.ck(hip.hipEventRecord(e0, None), "hipEventRecord")
        fn()
        rt.ck(hip.hipEventRecord(e1, None), "hipEventRecord")
        rt.ck(hip.hipEventSynchronize(e1), "hipEventSynchronize")
        rt.ck(hip.hipEventElapsedTime(ctypes.byref(ms), e0, e1), "hipEventElapsedTime")
        rt.ck(hip.hipEventDestroy(e0), "hipEventDestroy")
        rt.ck(hip.hipEventDestroy(e1), "hipEventDestroy")
        return float(ms.value)

    cyc, steps = 100_000, []                      # calibrate the spin to --kernel-ms
    for _ in range(10):
        m = dev_ms(lambda: writer("struct", X, HALF, cyc))
        steps.append((cyc, round(m, 3)))
        if 0.8 * a.kernel_ms <= m <= 1.25 * a.kernel_ms:
            break
        nxt = int(cyc * min(max(a.kernel_ms / max(m, 1e-3), 0.1), 50))
        if m * nxt / cyc > MAX_KERNEL_MS:
            raise SystemExit(f"repro_hip: the next calibration step would exceed "
                             f"{MAX_KERNEL_MS} ms")
        cyc = nxt
    else:
        raise SystemExit(f"repro_hip: the writer did not calibrate: {steps}")
    n_behind = 15
    behind_cyc = int(cyc * a.behind_ms / a.kernel_ms / n_behind)
    behind_ms = dev_ms(lambda: [writer("struct", SCR, SCRATCH_WORDS, behind_cyc)
                                for _ in range(n_behind)])
    rt.sync()
    rt.ck(hip.hipMemcpy(check, X, NB, D2H), "read back X")
    if any(v != s64(W) for v in check[:HALF]):
        raise SystemExit("repro_hip: the writer does not write W")
    print(f"repro_hip: writer {steps[-1][1]} ms (cycles {cyc}); queue ahead "
          f"{n_behind} kernels, {behind_ms:.1f} ms", flush=True)
    res = {"header": head, "writer": {"cycles": cyc, "ms": steps[-1][1],
                                      "calibration": steps},
           "behind": {"kernels": n_behind, "ms": round(behind_ms, 3)}, "cells": {}}

    rng = random.Random(a.seed)
    t_start = time.time()
    for cell in cells:
        kind = "ptr" if cell.endswith("-ptr") else "struct"
        record = not cell.endswith("-norec")
        st = {"iters": 0, "outcomes": {}, "copy_call_ms": []}
        t0 = time.time()
        while st["iters"] < a.iters_per_cell:
            if a.ceiling and time.time() - t_start > a.ceiling:
                st["stopped"] = "ceiling"
                break
            rt.ck(hip.hipMemcpy(X, old, NB, H2D), "fill X")           # step 1
            rt.sync()
            for _ in range(n_behind):                                 # step 2
                writer("struct", SCR, SCRATCH_WORDS, behind_cyc)
            writer(kind, X, HALF, cyc)                                # step 3
            reader()                                                  # step 4
            ev = vp()
            if record:                                                # step 5
                rt.ck(hip.hipEventCreateWithFlags(ctypes.byref(ev), EVENT_DISABLE_TIMING),
                      "hipEventCreateWithFlags")
                rt.ck(hip.hipEventRecord(ev, None), "hipEventRecord")
            if cell.startswith("upload"):                             # step 6
                c = [rng.getrandbits(62) for _ in range(NW)]
                host_c[:] = c
                tc = time.perf_counter()
                rt.ck(hip.hipMemcpyAsync(X, HC, NB, H2D, None), "hipMemcpyAsync")
            else:
                ctypes.memmove(host_h, sent, NB)
                tc = time.perf_counter()
                rt.ck(hip.hipMemcpyWithStream(host_h, X, NB, D2H, None),
                      "hipMemcpyWithStream")
            st["copy_call_ms"].append(round((time.perf_counter() - tc) * 1e3, 3))
            rt.sync()                                                 # step 7
            if record:
                rt.ck(hip.hipEventDestroy(ev), "hipEventDestroy")
            if cell.startswith("upload"):
                rt.ck(hip.hipMemcpy(check, X, NB, D2H), "read back X")
                outcome = classify_upload(list(check), c)
            else:
                outcome = classify_read(list(host_h))
            st["outcomes"][outcome] = st["outcomes"].get(outcome, 0) + 1
            st["iters"] += 1
        st["seconds"] = round(time.time() - t0, 1)
        ms = sorted(st.pop("copy_call_ms")) or [0.0]
        st["copy_call_ms_p50"] = ms[len(ms) // 2]
        res["cells"][cell] = st
        bad = sum(v for k, v in st["outcomes"].items() if k != "clean")
        print(f"repro_hip: {cell:13s} wrong {bad} / {st['iters']}   outcomes "
              f"{st['outcomes']}   copy call p50 {st['copy_call_ms_p50']} ms   "
              f"{st['seconds']} s", flush=True)
    if a.out:
        os.makedirs(a.out, exist_ok=True)
        with open(os.path.join(a.out, "repro_hip.json"), "w", encoding="utf-8") as f:
            json.dump(res, f, indent=1)
    print("repro_hip: expected with correct stream ordering: every cell wrong 0 / N",
          flush=True)


if __name__ == "__main__":
    main()
